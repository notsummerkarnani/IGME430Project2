const Advertisement = (props)=>{
    return(
        <img src={props.href} alt={props.alt} />
    )
}

module.exports = Advertisement;

